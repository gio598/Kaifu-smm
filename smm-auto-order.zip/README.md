# Auto Order SMM

Website order layanan SMM (BuzzerPanel) dengan sistem **bayar dulu, baru diproses** —
tanpa saldo/deposit. Customer pilih layanan → bayar QRIS (AustinPay) → begitu lunas,
order otomatis terkirim ke BuzzerPanel.

Semua kredensial API sudah dimasukkan dari project bot Telegram kamu (`austinpayService.js`
dan `buzzerpanelService.js`), jadi kalau kamu coba jalankan di komputer, harusnya langsung
nyambung — tinggal database-nya yang perlu kamu buat sendiri (gratis, 5 menit).

---

## Bagian 1 — Bikin Database Gratis (Neon)

Website ini butuh tempat nyimpen data order (biar customer bisa refresh halaman tanpa
kehilangan status). Kita pakai Neon karena gratis dan gak perlu install apa-apa.

1. Buka **https://neon.tech**, klik **Sign Up**, daftar pakai akun Google/GitHub (paling cepat).
2. Setelah masuk dashboard, klik **Create a project**. Kasih nama bebas, misal `smm-auto-order`. Klik **Create**.
3. Begitu project selesai dibuat, akan muncul kotak **Connection string**. Klik dropdown
   dan pastikan yang dipilih **Pooled connection**.
4. Copy connection string itu (bentuknya kira-kira `postgresql://namauser:passwordxxx@ep-xxx.neon.tech/namadb?sslmode=require`).
5. Simpan dulu, dipakai di Bagian 2 dan Bagian 3.

Itu saja — kamu **tidak perlu bikin tabel manual**. Website ini otomatis bikin tabel
sendiri begitu pertama kali dipakai.

---

## Bagian 2 — Coba di Komputer Sendiri (Opsional)

Kalau mau tes dulu sebelum deploy:

1. Buka file `.env.local` di project ini.
2. Isi baris `DATABASE_URL=` dengan connection string dari Bagian 1 (paste setelah tanda `=`, tanpa spasi/kutip).
3. Jalankan di terminal, di dalam folder project ini:
   ```
   npm install
   npm run dev
   ```
4. Buka `http://localhost:3000` di browser.

Kalau males coba lokal, boleh langsung lompat ke Bagian 3 (deploy ke Vercel).

---

## Bagian 3 — Deploy ke Vercel

1. Upload folder project ini ke GitHub (bikin repository baru, upload semua file
   KECUALI `node_modules` dan `.env.local` — dua itu memang sengaja gak ikut ke-upload,
   sudah diatur di `.gitignore`).
   - Cara paling gampang kalau belum biasa pakai `git`: buka https://github.com/new,
     bikin repo baru, lalu drag-and-drop semua file project (kecuali `node_modules`)
     lewat tombol **uploading an existing file** di halaman repo kosong.
2. Buka **https://vercel.com**, sign up/login pakai akun GitHub yang sama.
3. Klik **Add New... > Project**, pilih repository yang barusan kamu upload.
4. Sebelum klik Deploy, buka bagian **Environment Variables**, tambahkan satu-satu
   (Name di kiri, Value di kanan):

   | Name | Value |
   |---|---|
   | `BUZZERPANEL_API_URL` | `https://buzzerpanel.id/api/json.php` |
   | `BUZZERPANEL_API_KEY` | *(punya kamu, lihat `.env.local`)* |
   | `BUZZERPANEL_SECRET_KEY` | *(punya kamu, lihat `.env.local`)* |
   | `SMM_MARGIN_PROFIT` | `3500` |
   | `AUSTINPAY_API_KEY` | *(punya kamu, lihat `.env.local`)* |
   | `AUSTINPAY_API_SECRET` | *(punya kamu, lihat `.env.local`)* |
   | `AUSTINPAY_VERSION` | `v1` |
   | `AUSTINPAY_BASE_URL` | `https://austinstore.id` |
   | `DATABASE_URL` | *(connection string Neon dari Bagian 1)* |

5. Klik **Deploy**. Tunggu 1-2 menit.
6. Selesai — Vercel kasih link `https://nama-project-kamu.vercel.app`, itu website-nya
   sudah live.

Kalau nanti ganti margin keuntungan atau ganti API key, tinggal edit di
**Vercel > Settings > Environment Variables**, lalu klik **Redeploy** supaya kepakai.

---

## Cara Kerja Singkat (buat referensi kalau nanti mau diutak-atik)

- `app/page.js` — halaman utama, customer cari & pilih layanan, isi jumlah + link, klik Bayar.
- `app/api/checkout/route.js` — hitung ulang harga di server, minta QRIS ke AustinPay, simpan order ke database.
- `app/order/[orderId]/page.js` — halaman QR, auto-refresh tiap 5 detik.
- `app/api/status/[orderId]/route.js` — inti otomatisasinya: cek status bayar ke AustinPay,
  kalau **paid** langsung kirim order ke BuzzerPanel, lalu terus cek progress order-nya.
- `lib/austinpay.js` & `lib/buzzerpanel.js` — pemanggilan API, formatnya disalin persis dari
  bot Telegram kamu yang sudah terbukti jalan.

### Kalau order gagal terkirim ke BuzzerPanel padahal customer sudah bayar

Uang customer **tidak hilang begitu saja** — halaman order akan menampilkan pesan error dan
menyimpan detail order (layanan, jumlah, link target) di database supaya kamu bisa proses
manual dari dashboard BuzzerPanel. Biasanya penyebabnya saldo BuzzerPanel habis.
